

import Foundation
import Alamofire
import UIKit
import SwiftValidator

struct AppValidationRules {
    static var PasswordRules: [Rule] {
        return [
            RequiredRule(message: "Please enter a password"),
            RegexRule(regex: "^(?=.*?[A-Z])(?=.*?[0-9])(?=.*?[a-z]).*?$", message: "Password must contain at least one uppercase, one lowercase and one numeric character"),
            MinLengthRule(length: 8, message: "Password must have a minimum length of at least 8 characters"),
            MaxLengthRule(length: App.PasswordCharacterLimit, message: "Password must have a maximum length of \(App.PasswordCharacterLimit) characters")
        ]
    }
}

struct App {

    static let PasswordCharacterLimit: Int = 20

    static let Name: String = "Reddit"

    static let DateFormatDMY: String = "dd-MM-yyyy"
    static let DateFormat: String = "MM-dd-yyyy"

    static let TimeFormat: String = "h:mm a"
    static let FullDateFormat: String = "EEEE, MM d, yyyy"
    static let FullDateTimeFormat: String = "EEEE, MM-dd-yyyy HH:mm:ss"

    static let ServerDateFormat: String = "yyyy-MM-dd"
    static let ServerTimeFormat: String = "HH:mm:ss"
    static let ServerDateTimeFormat: String = "yyyy-MM-dd HH:mm:ss"

    struct Fonts {
        struct Signika {
            static let Regular = "Signika-Regular"
            static let Light = "Signika-Light"
            static let Bold = "Signika-Bold"
            static let SemiBold = "Signika-Semibold"
        }
        struct Roboto {
            static let Regular = "Roboto-Regular"
            static let Light = "Roboto-Light"
            static let Bold = "Roboto-Bold"
            static let Medium = "Roboto-Medium"
            static let Black = "Roboto-Black"
            static let Thin = "Roboto-Thin"
        }
        struct SFUIDisplay {
            static let Regular = "SFUIDisplay-Regular"
            static let Light = "SFUIDisplay-Light"
            static let Bold = "SFUIDisplay-Bold"
        }
    }
    struct StaticMSG {
        static let serverError = "Please Try Again!...Server Is Not Responding"
    }

    struct Colors {

        struct Gradient {
            static let topColor = UIColor(red: 94.0/255.0, green: 50.0/255.0, blue: 144.0/255.0, alpha: 1.0).cgColor
            static let midColor = UIColor(red: 100.0/255.0, green: 164.0/255.0, blue: 209.0/255.0, alpha: 1.0).cgColor
            static let bottomColor = UIColor(red: 80.0/255.0, green: 194.0/255.0, blue: 208.0/255.0, alpha: 1.0).cgColor
        }

        static let Pink = UIColor(red: 254/255, green: 40/255, blue: 81/255, alpha: 1)
        static let LighterGray = UIColor(red: 243.0/255.0, green: 243.0/255.0, blue: 243.0/255.0, alpha: 1)
        static let DarkerGray = UIColor(red: 74.0/255.0, green: 74.0/255.0, blue: 74.0/255.0, alpha: 1)
        static let DarkerGrayWithOpacity = UIColor(red: 74.0/255.0, green: 74.0/255.0, blue: 74.0/255.0, alpha: 0.7)
        static let DarkGray = UIColor(red: 137.0/255.0, green: 137.0/255.0, blue: 137.0/255.0, alpha: 1)
        static let Purple = UIColor(red: 106.0/255.0, green: 53.0/255.0, blue: 111.0/255.0, alpha: 1)
        static let GreenMix = UIColor(red: 76.0/255.0, green: 198.0/255.0, blue: 165.0/255.0, alpha: 1)
        static let SkyBlue = UIColor(red: 29.0/255.0, green: 175.0/255.0, blue: 221.0/255.0, alpha: 1)

        static let BorderColor = UIColor(red: 200.0/255.0, green: 199.0/255.0, blue: 204.0/255.0, alpha: 1.0)
        static let LightBackgroundColor = UIColor(red: 244.0/255.0, green: 244.0/255.0, blue: 244.0/255.0, alpha: 1.0)
        static let golden = UIColor(red: 250.0/255.0, green: 137.0/255.0, blue: 0.0/255.0, alpha: 1.0)

    }

    struct Devices {
        static let isIphone4 =  UIScreen.main.bounds.height < 568 ? true:false
        static let isIphone5 =  UIScreen.main.bounds.height == 568 ? true:false
        static let isIphone6_7 = UIScreen.main.bounds.height == 667 ? true:false
        static let isIphone6_7p = UIScreen.main.bounds.height == 736 ? true:false
        static let isIpad = UIScreen.main.bounds.height > 736 ? true:false

    }


    struct URLs {
        

         static let baseURL: String = "https://www.reddit.com/api"
        
      
        static let version: String = "v1"

        static let login = "access_token?"
    
    }

    enum DeepLinks: String {
        case verifyUser = "verify_user"
        case invite = "invite"

        static func allDeepLinks() -> [DeepLinks] {
            return [.verifyUser,.invite]
        }
    }

    enum Events: String {
        case UserSignedIn = "NSNotificationUserSignedIn"
        case LocationAccessAuthorisationChanged = "NSNotificationLocationAccessAuthorizationChanged"
        case UserLocationUpdated = "NSNotificationUserLocationUpdated"
        case UserProfileUpdated = "NSNotificationUserProfileUpdated"
        case NotificationReceived = "NSNotificationNotificationReceived"
        case NotificationRead = "NSNotificationNotificationRead"

        var NSNotificationName: NSNotification.Name {
            return NSNotification.Name(rawValue)
        }
    }
}
