

import Foundation
import UIKit

class GlobalVariables {
    
    static let sharedInstance = GlobalVariables()
    private init() {}
    
    var isMenuItemSelect = Bool()
    var flag = Bool(false)
}
