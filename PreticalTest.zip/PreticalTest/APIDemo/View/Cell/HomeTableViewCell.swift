//
//  HomeTableViewCell.swift
//  APIDemo
//
//  Created by Anil on 16/12/19.
//  Copyright © 2019 Anil. All rights reserved.
//

import UIKit
import SDWebImage

protocol HomeTableViewCellDelegate: NSObjectProtocol {
    
}

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var ImgCoverBg: UIImageView!
    @IBOutlet weak var ImgProfile: CircularImageView!
    @IBOutlet weak var BackgroundV: UIView!

    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var lblDescribation: UILabel!
    
    @IBOutlet weak var img1: CircularImageView!
    
    @IBOutlet weak var img3: CircularImageView!
    @IBOutlet weak var img2: CircularImageView!
    
    weak var delegate: HomeTableViewCellDelegate?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        self.BackgroundV.layer.borderWidth = 1
        self.BackgroundV.layer.borderColor = UIColor.lightGray.cgColor
               
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(for Posts: PopularPostsData) {
            ImgCoverBg.sd_setImage(with: URL(string: Posts.banner_img as String? ?? "" as String), placeholderImage: UIImage(named: ""))
             ImgProfile.sd_setImage(with: URL(string: Posts.header_img as String? ?? "" as String), placeholderImage: UIImage(named: ""))
            img1.sd_setImage(with: URL(string: Posts.icon_img as String? ?? "" as String), placeholderImage: UIImage(named: ""))
            img2.sd_setImage(with: URL(string: Posts.icon_img as String? ?? "" as String), placeholderImage: UIImage(named: ""))
            img3.sd_setImage(with: URL(string: Posts.icon_img as String? ?? "" as String), placeholderImage: UIImage(named: ""))
            lblTitle.text = "\(Posts.header_title ?? "No Title")"
        lblDescribation.text = "\(Posts.public_description ?? "No Title")"
            

        }

}


