//
//  HomeViewController.swift
//  APIDemo
//
//  Created by Anil on 16/12/19.
//  Copyright © 2019 Anil. All rights reserved.
//

import UIKit
import ObjectMapper

class HomeViewController: BaseViewController {

    @IBOutlet weak var tblPostlist: UITableView!
    
    var Dataarraycopy: NSArray =  []
    var PPostdata : [PopularPostsData]?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.setNavigationBarHidden(true, animated: false)

        
        callGetPopularPost()
      
    }
    

    
}

//MARK: - UITableViewDataSource Methods

extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return PPostdata?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
      //  let cell = tableView.dequeueReusableCell(withIdentifier: HomeTableViewCell.className, for: indexPath)
        
        let cell = tableView.dequeueReusableCell(withIdentifier: HomeTableViewCell.className, for: indexPath)
        
         if let cell = cell as? HomeTableViewCell {
            
          
            
//            self.PPostdata = dict as? [PopularPostsData]
//            print(self.PPostdata ?? "")
//            if let current = Mapper<PopularPostsData>().mapArray(JSONObject: dict) {
//                print(current)
//                self.PPostdata = [PopularPostsData]()
//
//                self.PPostdata = dict as? [PopularPostsData]
//                print(self.PPostdata)
//                //cell.configure(for: self.PPostdata)
//
//
//            }
            let pdata = (self.PPostdata?[indexPath.row])!
            cell.delegate = self as? HomeTableViewCellDelegate
            //self.PPostdata = pdata?.data
//            let PPosts = pdata?.data
            cell.configure(for: pdata)
        }

     
        
        return cell
    }
    
}
//MARK:- Web Service

extension HomeViewController {
    func callGetPopularPost() {
    
        APIManager.sharedInstance.get(url: "https://oauth.reddit.com/subreddits/popular", parameters: nil, headToken: 0, viewController: self, isLoadingIndicatorShow: true) { (jsonDict) in

            if let dictionary = (jsonDict.object(forKey: "data")) {
                    
                if let Dataarray = ((dictionary as AnyObject).object(forKey: "children")){
                    print(Dataarray)
                   // if let Datadict = (Dataarray as AnyObject).value(forKey: "data"){
                
                    if let popular = Mapper<PopularPostsData>().mapArray(JSONObject:(Dataarray as AnyObject).value(forKey: "data")) {
                        print(popular)
                        
                        
                        if popular.count != 0 {
                            self.PPostdata = [PopularPostsData]()
                            self.PPostdata = popular
                            self.tblPostlist.reloadData()
                        }
                    }
                }else{
                    print("Any object")

                }
                }else{
                        if let msg = jsonDict.object(forKey: "message") as? String  {
                        self.showAlert(title: App.Name, message: msg , viewController: self)
                }
                   
            }
               
        }
}
}

    


