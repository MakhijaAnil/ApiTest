

import UIKit
import SwiftValidator

class ViewController: BaseViewController {
    
    
    @IBOutlet weak var txtEmail: UITextField!
    
    @IBOutlet weak var txtPassword: UITextField!
    
  //  let validator = Validator()
    let validator = Validator()

    
    override func viewDidLoad() {
        super.viewDidLoad()
         self.navigationController?.setNavigationBarHidden(true, animated: false)

        txtEmail.text = "vikasaroy"
        txtPassword.text = "medley6one3"
        
       // registerValidationRules()
        
        // Do any additional setup after loading the view.
    }


}
//MARK:- Instance Methods
extension ViewController{
    
    func registerValidationRules() {
        validator.registerField(txtEmail, rules: [RequiredRule(message: "Please Enter Your Email")])
        validator.registerField(txtPassword, rules: [RequiredRule(message: "Please Enter Your Password")])
        validator.registerField(txtPassword, rules: AppValidationRules.PasswordRules)
    }
    
}

//MARK:- IBActions Action
extension ViewController{
    
    @IBAction func SignIn_Click(_ sender: UIButton) {
//        let controller = ScreenManager.getHomeViewController()
//        self.navigationController?.pushViewController(controller, animated: true)
        self.view.endEditing(true)
        let isCorrect = isValidPassword(testStr: txtPassword.text)
        if !isCorrect{
            let params: [String: Any] = ["grant_type":"password",
                                         "username":txtEmail.text!,
                                         "password":txtPassword.text!]

                   callSignIn(parameter: params)
        }else{
            self.showAlert(title:App.Name , message: "Password must have a minimum length of at least 8 characters", viewController: self)
        }

    }
   
}

//MARK:- Web services
extension ViewController{
    func callSignIn(parameter:[String:Any]) {
    
        APIManager.sharedInstance.post(url: App.URLs.login, parameters: parameter, headToken: 0, viewController: self, isLoadingIndicatorShow: true) { (jsonDict) in
            
            if jsonDict.object(forKey: "error") as? NSNumber  !=  401{
                let token = jsonDict.object(forKey: "access_token")
                UserDefaults.setDeviceToken(token as! String)
                
                let tokentype = jsonDict.object(forKey: "token_type")
                UserDefaults.setDeviceTokenType(tokentype as! String)
                
                let expires_in = jsonDict.object(forKey: "expires_in")
                UserDefaults.setexpires_in(expires_in as! Double)
                
                let controller = ScreenManager.getHomeViewController()
                self.navigationController?.pushViewController(controller, animated: true)
                
            } else {
                self.showAlert(title: App.Name, message: App.StaticMSG.serverError, viewController: self)
            }
        }
    }

}
