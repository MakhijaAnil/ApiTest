//
//  PopularPostsData.swift
//  APIDemo
//
//  Created by Anil on 16/12/19.
//  Copyright © 2019 Anil. All rights reserved.
//

import UIKit
import Foundation
import ObjectMapper
import CoreLocation

class PopularPostsData: Mappable {
    
    var accounts_active: NSString?
    var accounts_active_is_fuzzed: Double?
    var active_user_count: NSString?
    var advertiser_category: NSString?
    var all_original_content: Double?
    var allow_discovery: Double?
    var allow_images: Double?
    var allow_videogifs: Double?
    var allow_videos: Double?
    var banner_background_color: NSString?
    var banner_background_image: NSString?
    var banner_img: NSString?
    var can_assign_link_flair: Double?
    var can_assign_user_flair: Double?
    var collapse_deleted_comments: Double?
    var comment_score_hide_mins: Double?
    var community_icon: Double?
    var created: Double?
    var created_utc: Double?
    var description: NSString?
    var description_html: NSString?
    var disable_contributor_requests: Double?
    var display_name: Double?
    var display_name_prefixed: NSString?
    var emojis_custom_size: NSString?
    var emojis_enabled: Double?
    var free_form_reports: Double?
    var has_menu_widget: Double?
    var header_img: NSString?
    var header_title: NSString?
    var hide_ads: Double?
    var icon_img: NSString?
    var id: Double?
    var is_crosspostable_subreddit: NSString?
    var is_enrolled_in_new_modmail: NSString?
    var key_color: NSString?
    var lang: NSString?
    var link_flair_enabled: Double?
    var link_flair_position: NSString?
    var mobile_banner_image: NSString?
    var name: NSString?
    var notification_level: NSString?
    var original_content_tag_enabled: Double?
    var over18: Double?
    var primary_color: NSString?
    var public_description: NSString?
    var public_traffic: Double?
    var quarantine: Double?
    var restrict_commenting: Double?
    var restrict_posting: Double?
    var show_media: Double?
    var show_media_preview: Double?
    var spoilers_enabled: Double?
    var submission_type: NSString?
    var submit_link_label: NSString?
    var submit_text: NSString?
    var submit_text_html: NSString?
    var submit_text_label: NSString?
    var subreddit_type: NSString?
    var subscribers: Double?
    var suggested_comment_sort: NSString?
    var title: NSString?
    var url: NSString?
    var user_can_flair_in_sr: NSString?
    var user_flair_background_color: NSString?
    var user_flair_css_class: NSString?
    var user_flair_enabled_in_sr: Double?
    var user_flair_position: NSString?
    var user_flair_template_id: NSString?
    var user_flair_text: NSString?
    var user_flair_text_color: NSString?
    var user_flair_type: NSString?
    var user_has_favorited: Double?
    var user_is_banned: Double?
    var user_is_contributor: Double?
    var user_is_moderator: Double?
    var user_is_muted: Double?
    var user_is_subscriber: Double?
    var user_sr_flair_enabled: NSString?
    var user_sr_theme_enabled: Double?
    var whitelist_status: NSString?
    var wiki_enabled: Double?
    var wls: Double?
    var kind: NSString?
    
    
    
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        accounts_active <- map["accounts_active"]
        accounts_active_is_fuzzed <- map["accounts_active_is_fuzzed"]
        active_user_count <- map["active_user_count"]
        advertiser_category <- map["advertiser_category"]
        all_original_content <- map["all_original_content"]
        allow_discovery <- map["allow_discovery"]
        allow_images <- map["allow_images"]
        allow_videogifs <- map["allow_videogifs"]
        allow_videos <- map["allow_videos"]
        banner_background_color <- map["banner_background_color"]
        banner_background_image <- map["banner_background_image"]
        banner_img <- map["banner_img"]
        can_assign_link_flair <- map["can_assign_link_flair"]
        can_assign_user_flair <- map["can_assign_user_flair"]
        collapse_deleted_comments <- map["collapse_deleted_comments"]
        comment_score_hide_mins <- map["comment_score_hide_mins"]
        community_icon <- map["community_icon"]
        created <- map["created"]
        created_utc <- map["created_utc"]
        description <- map["description"]
        description_html <- map["description_html"]
        disable_contributor_requests <- map["disable_contributor_requests"]
        display_name <- map["display_name"]
        display_name_prefixed <- map["display_name_prefixed"]
        emojis_custom_size <- map["emojis_custom_size"]
        emojis_enabled <- map["emojis_enabled"]
        free_form_reports <- map["free_form_reports"]
        has_menu_widget <- map["has_menu_widget"]
        header_img <- map["header_img"]
        header_title <- map["header_title"]
        hide_ads <- map["hide_ads"]
        icon_img <- map["icon_img"]
        id <- map["id"]
        is_crosspostable_subreddit <- map["is_crosspostable_subreddit"]
        is_enrolled_in_new_modmail <- map["is_enrolled_in_new_modmail"]
        key_color <- map["key_color"]
        lang <- map["lang"]
        link_flair_enabled <- map["link_flair_enabled"]
        link_flair_position <- map["link_flair_position"]
        mobile_banner_image <- map["mobile_banner_image"]
        name <- map["name"]
        notification_level <- map["notification_level"]
        original_content_tag_enabled <- map["original_content_tag_enabled"]
        over18 <- map["over18"]
        primary_color <- map["primary_color"]
        public_description <- map["public_description"]
        public_traffic <- map["public_traffic"]
        quarantine <- map["quarantine"]
        restrict_commenting <- map["restrict_commenting"]
        restrict_posting <- map["restrict_posting"]
        show_media <- map["show_media"]
        show_media_preview <- map["show_media_preview"]
        spoilers_enabled <- map["spoilers_enabled"]
        submission_type <- map["submission_type"]
        submit_link_label <- map["submit_link_label"]
        submit_text <- map["submit_text"]
        submit_text_html <- map["submit_text_html"]
        submit_text_label <- map ["submit_text_label"]
        subreddit_type <- map["subreddit_type"]
        subscribers <- map["subscribers"]
        suggested_comment_sort <- map["suggested_comment_sort"]
        title <- map["title"]
        url <- map["url"]
        user_can_flair_in_sr <- map["user_can_flair_in_sr"]
        user_flair_background_color <- map["user_flair_background_color"]
        user_flair_css_class <- map["user_flair_css_class"]
        user_flair_enabled_in_sr <- map["user_flair_enabled_in_sr"]
        user_flair_position <- map["user_flair_position"]
        user_flair_template_id <- map["user_flair_template_id"]
        user_flair_text <- map["user_flair_text"]
        user_flair_text_color <- map["user_flair_text_color"]
        user_flair_type <- map["user_flair_type"]
        user_has_favorited <- map["user_has_favorited"]
        user_is_banned <- map["user_is_banned"]
        user_is_contributor <- map["user_is_contributor"]
        user_is_moderator <- map["user_is_moderator"]
        user_is_muted <- map["user_is_muted"]
        user_is_subscriber <- map["user_is_subscriber"]
        user_sr_flair_enabled <- map["user_sr_flair_enabled"]
        user_sr_theme_enabled <- map["user_sr_theme_enabled"]
        whitelist_status <- map["whitelist_status"]
        wiki_enabled <- map["wiki_enabled"]
        wls <- map["wls"]
        kind <- map["kind"]
                   
        
    }
    

}
