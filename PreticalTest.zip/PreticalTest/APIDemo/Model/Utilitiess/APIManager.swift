
import Foundation
import UIKit
import Alamofire
import MBProgressHUD

class APIManager {
    static let sharedInstance = APIManager()
    let baseController = BaseViewController()
    var progressHUD: MBProgressHUD?
    
    private init() {
        
    }
    

    
    func get(url:String, parameters: [String: Any]?, headToken:Int , viewController : UIViewController? , isLoadingIndicatorShow:Bool , completionHandler:@escaping (NSDictionary)-> Void ) {
        
        let isConnectedInternet = baseController.isConnectedToNetwork()
        
        if isConnectedInternet {
            
            if isLoadingIndicatorShow == true {
                if (viewController != nil) {
                    baseController.startIndicator(viewController: viewController!)
                }
            }

//            let urlString = NSString(string:"\(App.URLs.baseURL)/\(App.URLs.version)/\(url)")
//            print("WS - URL- \(urlString)")
            print("Pass Parameter - \(String(describing: parameters))")
            print("Head token- \(headToken)")

            var combinedHeaders = HTTPHeaders()
            combinedHeaders["Authorization"] = "bearer " + UserDefaults.getDeviceToken()! //"bearer 355169843007--GqKIYsDM02nRgaUToiWpEj9md"
    

            Alamofire.request("\(url)", method: .get, parameters: parameters, encoding: URLEncoding.methodDependent, headers: combinedHeaders).responseJSON(completionHandler: { (response) in
                
                if isLoadingIndicatorShow == true {
                    if (viewController != nil) {
                        self.baseController.stopIndicator(viewController: viewController!)
                    }
                }
                switch response.result {
                case .success(let responseJSON):
                    completionHandler(responseJSON as! NSDictionary)
                    print(responseJSON)
                case .failure(let errorObj):
                    if (viewController != nil) {
                        self.baseController.showAlert(title:App.Name , message: errorObj.localizedDescription, viewController: viewController!)
                    }
                }
            })
        } else {
            if (viewController != nil) {
                self.baseController.showAlert(title: App.Name, message :"Please Check Internet Connection" , viewController: viewController!)
            }
        }
    }

    
    func post(url:String, parameters: [String: Any]?, headToken:Int, viewController : UIViewController? , isLoadingIndicatorShow:Bool , completionHandler:@escaping (NSDictionary)-> Void ) {
        
        let isConnectedInternet = baseController.isConnectedToNetwork()
        
        if isConnectedInternet {
            
            if isLoadingIndicatorShow == true {
                if (viewController != nil) {
                    baseController.startIndicator(viewController: viewController!)
                }
            }
            
            let urlString = NSString(string:"\(App.URLs.baseURL)/\(App.URLs.version)/\(url)")
            let configration = Alamofire.Request.authorizationHeader(user: "sG7WikFP8UbFlQ", password: "9NwUSuG3IZf-pJKoQ-vp8oWAZqs")!
            print("WS - URL- \(urlString)")
            print("Pass Parameter - \(parameters)")
            print("Head token- \(headToken)")
            
          //  var combinedHeaders = HTTPHeaders()
            let combinedHeaders = HTTPHeaders(dictionaryLiteral: configration)


            Alamofire.request("\(urlString)", method: .post, parameters: parameters, encoding: URLEncoding.methodDependent, headers: combinedHeaders).responseJSON(completionHandler: { (response) in
                
                if isLoadingIndicatorShow == true {
                    if (viewController != nil) {
                        self.baseController.stopIndicator(viewController: viewController!)
                    }
                }
                    switch response.result {
                    case .success(let responseJSON):
                        completionHandler(responseJSON as! NSDictionary)
                    case .failure(let errorObj):
                        if (viewController != nil) {
                            self.baseController.showAlert(title:App.Name , message: errorObj.localizedDescription, viewController: viewController!)
                        }
                    }
            })
            } else {
            if (viewController != nil) {
                self.baseController.showAlert(title: App.Name, message :"Please Check Internet Connection" , viewController: viewController!)
            }
        }
    }

    
//    func upload(url:String, parameters: [String: Any]?,imagesParameter:[String:UIImage]?, headToken:Int, viewController : UIViewController,isLoadingIndicatorShow:Bool , completionHandler:@escaping (NSDictionary)-> Void) {
//        
//        let isConnectedInternet = baseController.isConnectedToNetwork()
//        if isConnectedInternet {
//            
//            if isLoadingIndicatorShow == true {
//                
//                progressHUD = nil
//                progressHUD = MBProgressHUD.showAdded(to: viewController.view, animated: true)
//                progressHUD?.animationType = .zoom
//                progressHUD?.mode = .determinate
//                progressHUD?.label.text = "Uploading"
//            }
//            
//            let urlString = NSString(string:"\(App.URLs.baseURL)/\(App.URLs.version)/\(url)")
//            
//            let parameterString = parameters?.stringFromHttpParameters()
//            
//            print("WS - URL- \(urlString)")
//            print("Pass Parameter - \(parameterString)")
//            print("Head token- \(headToken)")
//
//            Alamofire.upload(
//                multipartFormData: { multipartFormData in
//                    if let images = imagesParameter {
//                        for (name, image) in images {
////                            if let imageData = UIImageJPEGRepresentation(image, 0.6) {
////                                multipartFormData.append(imageData, withName: name, fileName: "\(UUID()).jpeg", mimeType: "image/jpeg")
////                            }
//                        }
//                    }
//                    
//                    if let parameters = parameters {
//                        for (key, value) in parameters {
//                            let stringValue = "\(value)"
//                            multipartFormData.append((stringValue.data(using: .utf8))!, withName: key)
//                        }
//                    }
//            },
//                to: "\(urlString)",
//                method: .post,
//                headers: ["btv_header_token":"\(headToken)"],
//                encodingCompletion: { encodingResult in
//                    switch encodingResult {
//                    case .success(let upload, _, _):
//                        
//                        upload.uploadProgress(closure: { (progress) in
//                            self.progressHUD?.progress = Float(progress.fractionCompleted)
//                        })
//                                                
//                        upload.responseJSON { response in
//                            
//                            self.progressHUD?.hide(animated: true)
//                            
//                            switch response.result {
//                            case .success(let responseJSON):
//                                completionHandler(responseJSON as! NSDictionary)
//                            case .failure(let errorObj):
//                                self.baseController.showAlert(title:App.Name , message: "\(errorObj.localizedDescription)", viewController: viewController)
//                            }
//                        }
//                        
//                    case .failure(let encodingError):
//                        self.progressHUD?.hide(animated: true)
//                        self.baseController.showAlert(title:App.Name , message: "\(encodingError.localizedDescription)", viewController: viewController)
//                    }
//            })
//            
//        } else {
//            self.baseController.showAlert(title: App.Name, message :"Please Check Internet Connection" , viewController: viewController)
//        }
//    }
    
    
    func getGooglePlace(url:String, parameters: [String: Any]?, headToken:Int , viewController : UIViewController? , isLoadingIndicatorShow:Bool , completionHandler:@escaping (NSDictionary)-> Void ) {
        
        let isConnectedInternet = baseController.isConnectedToNetwork()
        
        if isConnectedInternet {
            
            if isLoadingIndicatorShow == true {
                if (viewController != nil) {
                    baseController.startIndicator(viewController: viewController!)
                }
            }
            
            let urlString = NSString(string:"\(url)")
            print("WS - URL- \(urlString)")
            print("Pass Parameter - \(parameters)")
            print("Head token- \(headToken)")
            
            var combinedHeaders = HTTPHeaders()
            combinedHeaders["Content-Type"] = "application/x-www-form-urlencoded"
            combinedHeaders["btv_header_token"] = "\(headToken)"
            
            
            Alamofire.request("\(urlString)", method: .get, parameters: parameters, encoding: URLEncoding.methodDependent, headers: combinedHeaders).responseJSON(completionHandler: { (response) in
                
                if isLoadingIndicatorShow == true {
                    if (viewController != nil) {
                        self.baseController.stopIndicator(viewController: viewController!)
                    }
                }
                switch response.result {
                case .success(let responseJSON):
                    completionHandler(responseJSON as! NSDictionary)
                case .failure(let errorObj):
                    if (viewController != nil) {
                        self.baseController.showAlert(title:App.Name , message: errorObj.localizedDescription, viewController: viewController!)
                    }
                }
            })
        } else {
            if (viewController != nil) {
                self.baseController.showAlert(title: App.Name, message :"Please Check Internet Connection" , viewController: viewController!)
            }
        }
    }


    
    func zipCodeVerify(url:String, parameters: [String: Any]?, headToken:Int , viewController : UIViewController? , isLoadingIndicatorShow:Bool , completionHandler:@escaping (NSDictionary)-> Void ) {
        
        let isConnectedInternet = baseController.isConnectedToNetwork()
        
        if isConnectedInternet {
            
            if isLoadingIndicatorShow == true {
                if (viewController != nil) {
                    baseController.startIndicator(viewController: viewController!)
                }
            }
            
            var parameterString = String()
            
            if parameters == nil {
                parameterString = ""
            } else {
                parameterString = parameters!.stringFromHttpParameters()
            }
            
            print(parameterString)
            var urlString = NSString(string:"\(url)\(parameterString)")
            
            print("WS URL----->>" + (urlString as String))
            print("Parameter----->> \(parameterString)")
            print("HeaderToken----->> \(headToken)")
            
            urlString = urlString .replacingOccurrences(of: " ", with: "%20") as NSString
            
            let url:NSURL = NSURL(string: urlString as String)!
            let session = URLSession.shared
            
            let request = NSMutableURLRequest(url: url as URL )
            request.httpMethod = "GET"
            request.cachePolicy = NSURLRequest.CachePolicy.reloadIgnoringCacheData
            let task = session.dataTask(with: request as URLRequest, completionHandler: {data, response, error -> Void in
                
                OperationQueue.main.addOperation {
                    if isLoadingIndicatorShow == true {
                        if (viewController != nil) {
                            self.baseController.stopIndicator(viewController: viewController!)
                        }
                    }
                    
                    if error != nil {
                        
                        if (viewController != nil) {
                            self.baseController.showAlert(title:App.Name , message: error?.localizedDescription, viewController: viewController!)
                        }
                    } else {
                        
                        if data == nil {
                            if (viewController != nil) {
                                self.baseController.showAlert(title:App.Name , message: "Server is not responding", viewController: viewController!)
                            }
                            
                        } else {
                            
                            let jsonResult: AnyObject = try! JSONSerialization.jsonObject(with: data!, options:JSONSerialization.ReadingOptions.allowFragments) as AnyObject
                            
                            completionHandler(jsonResult as! NSDictionary)
                        }
                    }
                }
            })
            
            task.resume()
        } else {
            if (viewController != nil) {
                self.baseController.showAlert(title: App.Name, message :"Please Check Internet Connection" , viewController: viewController!)
            }
        }
    }

    
}

extension Dictionary {
    
    func stringFromHttpParameters() -> String {
        
        let cookieHeader = (self.flatMap({ (key, value) -> String in
            return "\(key)=\(value)"
        }) as Array).joined(separator: "&")
        
        return cookieHeader
    }
    
}

extension Data {
    
//    mutating func append(_ string: String) {
//        if let data = string.data(using: .utf8) {
//            append(data)
//        }
//    }
}

