

import Foundation
import UIKit

class TextUtilities {
    
    static let sharedInstance = TextUtilities()

    private init() {}
    
    func attributedText(boldText:String, lightText:String , fontSize:CGFloat, textSwap:Bool) -> NSAttributedString {
        
        let attrs1 = [NSFontAttributeName : UIFont.systemFont(ofSize: fontSize, weight: UIFontWeightBold), NSForegroundColorAttributeName : App.Colors.DarkerGray]
        
        let attrs2 = [NSFontAttributeName : UIFont.systemFont(ofSize: fontSize, weight: UIFontWeightLight), NSForegroundColorAttributeName : App.Colors.DarkGray]
        
        let attributedString1 = NSMutableAttributedString(string:boldText, attributes:attrs1)
        let attributedString2 = NSMutableAttributedString(string:lightText, attributes:attrs2)
        
        
        let attributedTitle = NSMutableAttributedString()
        
        if textSwap == true {
            attributedTitle.append(attributedString2)
            attributedTitle.append(attributedString1)
        } else {
            attributedTitle.append(attributedString1)
            attributedTitle.append(attributedString2)
        }

        return attributedTitle
    }
    
    func attributedTextWithSignika(text:String,isRefund:Bool) -> NSAttributedString {
        
        var color:UIColor!
        var title:String!
        
        if isRefund == true {
            color = UIColor.red
            title = " DR"
        } else {
            color = App.Colors.GreenMix
            title = " CR"
        }
        

        let attrs1: [String : Any] = [NSFontAttributeName : UIFont(name: App.Fonts.Signika.Bold, size: 15)!, NSForegroundColorAttributeName : color]
        
        let attrs2: [String : Any] = [NSFontAttributeName : UIFont(name: App.Fonts.Signika.Light, size: 15)!, NSForegroundColorAttributeName : App.Colors.DarkerGray]

        
        let attributedString1 = NSMutableAttributedString(string:text, attributes:attrs1)
        let attributedString2 = NSMutableAttributedString(string:title, attributes:attrs2)
        
        let attributedTitle = NSMutableAttributedString()
        attributedTitle.append(attributedString1)
        attributedTitle.append(attributedString2)
        
        return attributedTitle
    }
    
    func accountAttributedText(accountNumber:String,bankName:String) -> NSAttributedString {
        
        var title:String!
        var title1:String!
        var title2:String!
        var title3:String!
        
        title = "Funds transferred to "
        title1 = "Checking Account \(accountNumber) "
        title2 = "at "
        title3 = "\(bankName)"
        
        let attrs1 = [NSFontAttributeName : UIFont.systemFont(ofSize: App.Devices.isIphone5 ? 10:13, weight: UIFontWeightRegular), NSForegroundColorAttributeName : App.Colors.DarkerGray]
        
        let attrs2 = [NSFontAttributeName : UIFont.systemFont(ofSize: App.Devices.isIphone5 ? 10:13, weight: UIFontWeightRegular), NSForegroundColorAttributeName : App.Colors.DarkGray]
        
        let attributedString1 = NSMutableAttributedString(string:title, attributes:attrs2)
        let attributedString2 = NSMutableAttributedString(string:title1 + "\n", attributes:attrs1)
        let attributedString3 = NSMutableAttributedString(string:title2, attributes:attrs2)
        let attributedString4 = NSMutableAttributedString(string:title3, attributes:attrs1)
        
        let attributedTitle = NSMutableAttributedString()
        attributedTitle.append(attributedString1)
        attributedTitle.append(attributedString2)
        attributedTitle.append(attributedString3)
        attributedTitle.append(attributedString4)
        
        return attributedTitle
    }
    
    
    func sessionDetailAttributedText(sessionPlace:String ,placeAddress:String ,placePhone:String ,placeEmail:String) -> NSAttributedString {
    let attributedString = NSMutableAttributedString()
        
        attributedString.append(NSAttributedString(
            string: sessionPlace + "\n",
            attributes: [
                NSFontAttributeName: UIFont.boldSystemFont(ofSize: 12.0)
            ]))
        
        attributedString.append(NSAttributedString(
            string: placeAddress + "\n",
            attributes: [
                NSFontAttributeName: UIFont.systemFont(ofSize: 12, weight: UIFontWeightLight)
            ]))
        
        attributedString.append(NSAttributedString(
            string: "Tel ",
            attributes: [
                NSFontAttributeName: UIFont.systemFont(ofSize: 12)
            ]))
        
        attributedString.append(NSAttributedString(
            string: placePhone + "\n",
            attributes: [
                NSFontAttributeName: UIFont.systemFont(ofSize: 12, weight: UIFontWeightLight)
            ]))
        
        attributedString.append(NSAttributedString(
            string: "Email ",
            attributes: [
                NSFontAttributeName: UIFont.systemFont(ofSize: 12)
            ]))
        
        attributedString.append(NSAttributedString(
            string: placeEmail + "\n",
            attributes: [
                NSFontAttributeName: UIFont.systemFont(ofSize: 12, weight: UIFontWeightLight)
            ]))
        
        return attributedString
    }
    
    
    func dataSlugAttributedText(title:String, value:String) -> NSMutableAttributedString {
        let attributedString = NSMutableAttributedString()
        
        attributedString.append(NSAttributedString(
            string: title + "\n",
            attributes: [
                NSFontAttributeName: UIFont.boldSystemFont(ofSize: 15.0)
            ]))
        
        attributedString.append(NSAttributedString(
            string: value + "\n",
            attributes: [
                NSFontAttributeName: UIFont.systemFont(ofSize: 13.0, weight: UIFontWeightLight)
            ]))
        
        
        return attributedString
    }

    class func getDistanceAttributedString(distance: Double, font: UIFont) -> NSAttributedString {
        let attachment = NSTextAttachment()
        
        if let image =  UIImage(named: "icon-landmark-small")?.withRenderingMode(.alwaysTemplate) {
            attachment.image = image
            attachment.bounds = CGRect(x: 0, y: font.descender, width: image.size.width, height: image.size.height)
        }
        
        let distanceString = NSMutableAttributedString(attributedString: NSAttributedString(attachment: attachment))
        
        distanceString.append(NSAttributedString(string: " "))
        
        distanceString.append(NSAttributedString(string: String(format: "%.1f mi", distance)))
        
        return distanceString
    }
    
    class func getUserLocationAndDistanceString(user: UserModel, distance: Double, font: UIFont) -> NSAttributedString {
        let attributedString = NSMutableAttributedString(attributedString: NSAttributedString(string: getUserLocationString(user: user)))
        
        attributedString.append(NSAttributedString(string: "  |  "))
        attributedString.append(NSAttributedString(
            string: String(format: "%.1f", distance),
            attributes: [
                NSFontAttributeName: UIFont.boldSystemFont(ofSize: font.pointSize)
            ]))
        attributedString.append(NSAttributedString(string: "mi"))
        
        return attributedString
    }
    
    class func getUserLocationString(user: UserModel) -> String {
        var locationComponents: [String] = []
        
        if let state = user.state {
            locationComponents.append(state)
        }
        
        if let country = user.country {
            locationComponents.append(country)
        }
        
        return locationComponents.joined(separator: ", ")
    }
    
    class func getRatingString(rating: Double?) -> String {
        if let rating = rating {
            return String(format: "%.2f%%", rating)
        }
        
        return "No ratings available"
    }
    
    class func getPriceString(price: Double) -> String {
        return String(format: "$%.2f", price)
    }
    
   
}
