

import Foundation
import UIKit
import AKSideMenu

class ScreenManager {
    // hide the initializer
    private init() {}
    
    class func setAsMainViewController(_ viewController: UINavigationController) {
        let window = UIApplication.shared.keyWindow
        window?.rootViewController = viewController
    }
    
    class func mainStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    
   class func embedNavigationController(viewController:UIViewController) -> UINavigationController {
        let navController = UINavigationController(rootViewController: viewController)
        navController.isNavigationBarHidden = true
        return navController
    }
    
    
    class func getDashboardViewController() -> ViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: ViewController.className) as! ViewController
    }
    class func getHomeViewController() -> HomeViewController {
        return mainStoryboard().instantiateViewController(withIdentifier: HomeViewController.className) as! HomeViewController
    }
    
}
