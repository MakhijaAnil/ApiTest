

import Foundation
import UIKit
import SwiftDate

class DateTimeFormatter {
    static let shared = DateTimeFormatter()
    
    private(set) var sourceDateFormatter: DateFormatter
    private(set) var sourceTimeFormatter: DateFormatter
    private(set) var sourceDateTimeFormatter: DateFormatter
    
    private(set) var dateFormatter: DateFormatter
    private(set) var dateFormatterDMY: DateFormatter
    private(set) var timeFormatter: DateFormatter
    private(set) var fullDateFormatter: DateFormatter
    private(set) var fullDateTimeFormatter: DateFormatter

    
    private init() {
        sourceDateFormatter = DateFormatter()
        sourceTimeFormatter = DateFormatter()
        sourceDateTimeFormatter = DateFormatter()
        dateFormatter = DateFormatter()
        timeFormatter = DateFormatter()
        fullDateFormatter = DateFormatter()
        fullDateTimeFormatter = DateFormatter()
        dateFormatterDMY = DateFormatter()
        
        sourceDateFormatter.dateFormat = App.ServerDateFormat
        sourceTimeFormatter.dateFormat = App.ServerTimeFormat
        sourceDateTimeFormatter.dateFormat = App.ServerDateTimeFormat
        
        dateFormatter.dateFormat = App.DateFormat
        dateFormatterDMY.dateFormat = App.DateFormatDMY
        timeFormatter.dateFormat = App.TimeFormat
        fullDateFormatter.dateFormat = App.FullDateFormat
        fullDateTimeFormatter.dateFormat = App.FullDateTimeFormat
    }
    
    class func format(date: Date, showFull: Bool = false) -> String {
        if showFull {
            return shared.fullDateFormatter.string(from: date)
        }
        
        return shared.dateFormatter.string(from: date)
    }
    
    
    class func fullDateTimeformat(date: Date) -> String {
            return shared.fullDateTimeFormatter.string(from: date)
    }
    
    class func format(time: Date) -> String {
        return shared.timeFormatter.string(from: time).lowercased()
    }
    
    class func date(from dateString: String) -> Date? {
        return shared.dateFormatter.date(from: dateString)
    }
    
    class func dateDMY(from dateString: String) -> Date? {
        return shared.dateFormatterDMY.date(from: dateString)
    }
    
    class func dateDMYString(from date: Date) -> String {
        return shared.dateFormatterDMY.string(from: date)
    }
    
    class func serverDate(from dateString: String) -> Date? {
        return shared.sourceDateFormatter.date(from: dateString)
    }
    
    class func serverDateString(from date: Date) -> String {
        return shared.sourceDateFormatter.string(from: date)
    }
    
    class func serverTimeString(from date: Date) -> String {
        return shared.sourceTimeFormatter.string(from: date)
    }
    
    class func serverTime(from dateTimeString: String) -> Date? {
        return shared.sourceTimeFormatter.date(from: dateTimeString)
    }
    

    class func serverDateTime(from dateTimeString: String) -> Date? {
        return shared.sourceDateTimeFormatter.date(from: dateTimeString)
    }
    
    class func serverDateTimeString(from date: Date) -> String {
        return shared.sourceDateTimeFormatter.string(from: date)
    }
    
    class func time(from timeString: String) -> Date? {
        let calendar = Calendar.current
        
        if let date = shared.timeFormatter.date(from: timeString) {
            let components = calendar.dateComponents([.minute, .hour], from: date)
            let today = Date()
            
            var newComponents = DateComponents()
            newComponents.year = today.year
            newComponents.month = today.month
            newComponents.day = today.day
            newComponents.hour = components.hour
            newComponents.minute = components.minute
            newComponents.second = 0
            
            return calendar.date(from: newComponents)
        }
        return nil
    }
    
    class func getAllDates( startDate:Date ,endDate:Date) -> [Date] {
        
        var date = [Date]()
        var startDate = startDate
        let calendar = Calendar(identifier: .gregorian)
        
        // Formatter for printing the date, adjust it according to your needs:
        let fmt = DateFormatter()
        fmt.dateFormat = "dd/MM/yyyy"
        
        date.append(startDate)
        print(fmt.string(from: startDate))

        while startDate <= endDate {

            startDate = calendar.date(byAdding: .day, value: 1, to: startDate)!
            print(fmt.string(from: startDate))

            date.append(startDate)

        }
        
        return date
    }
    
    class func getDayID(date:Date!) -> Int? {

        guard let todayDate = date else { return nil }
        let myCalendar = Calendar(identifier: .gregorian)
        let weekDay = myCalendar.component(.weekday, from: todayDate)
        return weekDay
    }
    

    
    class func addTimeInterval(time:Date,minutes:Int) -> String? {
    
        let calendar = Calendar.current
        let date = calendar.date(byAdding: .minute, value: minutes, to: time)

       let addedTime = format(time: date!)
        
        if addedTime.isEmpty {
            return nil
        } else {
            return addedTime
        }
    }
    
    class func formattedDateConvetToString(dateString: String, currentFormat:String,convertFormat: String) -> String? {
        
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = currentFormat
        
        if let date = inputFormatter.date(from: dateString) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = convertFormat
            return outputFormatter.string(from: date)
        }
        
        return nil
        
    }
    
    class func formattedTimeConvetToString(timeString: String, currentFormat:String,convertFormat: String) -> String? {
        
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = currentFormat
        
        if let date = inputFormatter.date(from: timeString) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = convertFormat
            return outputFormatter.string(from: date)
        }
        
        return nil
        
    }
    
    
    class func formattedDateFromString(dateString: String, withFormat format: String) -> String? {
        
//        let inputFormatter = DateFormatter()
//        inputFormatter.dateFormat = "yyyy-MM-dd"
//        
//        if let date = inputFormatter.date(from: dateString) {
        
        if let date = shared.sourceDateFormatter.date(from: dateString) {
            let outputFormatter = DateFormatter()
            outputFormatter.dateFormat = format
            
            return outputFormatter.string(from: date)
        }
        
        return nil
    }
    
}
