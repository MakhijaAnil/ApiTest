

import Foundation
import UIKit
import ObjectMapper

enum userDefaultKeys:String {
    case isLoggesIn = "userLoogedIn"
    case userDetail = "user_detail"
    case expires_in = "expires_in"
    case deviceToken = "token"
    case deviceTokenType = "tokentype"

}

extension UserDefaults {
    
    static func customSet(value:String, key:String) {
    }
    
    static func get(key:userDefaultKeys)->String {
      return  self.value(forKey: userDefaultKeys(rawValue: key.rawValue)!.rawValue) as! String
    }
    
   
    
    
    
    static func clearUserData() {
        standard.removeObject(forKey: userDefaultKeys.userDetail.rawValue)
    }
    
    static func setDeviceToken(_ token: String) {
        standard.set(token, forKey: userDefaultKeys.deviceToken.rawValue)
    }
    
    static func getDeviceToken() -> String? {
        return standard.value(forKey: userDefaultKeys.deviceToken.rawValue) as? String
    }
    static func setDeviceTokenType(_ token: String) {
           standard.set(token, forKey: userDefaultKeys.deviceTokenType.rawValue)
       }
       
    static func getDeviceTokenType() -> String? {
           return standard.value(forKey: userDefaultKeys.deviceTokenType.rawValue) as? String
       }
    
    static func setexpires_in(_ token: Double) {
           standard.set(token, forKey: userDefaultKeys.expires_in.rawValue)
       }
       
    static func getexpires_in() -> Double? {
           return standard.value(forKey: userDefaultKeys.expires_in.rawValue) as? Double
       }
    
}
